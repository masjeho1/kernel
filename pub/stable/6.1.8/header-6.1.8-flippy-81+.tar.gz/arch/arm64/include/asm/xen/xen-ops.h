/* SPDX-License-Identifier: GPL-2.0 */
#include <xen/arm/xen-ops.h>
